"""Prédiction de billets contrefaits — ONCFM.

Usage : python predire_billets.py
Une fenêtre s'ouvre pour choisir le fichier (CSV ou Excel), les résultats
s'affichent dans le terminal et sont exportés en CSV à côté du fichier source.
Prérequis : pandas, scikit-learn, joblib (openpyxl pour les .xlsx).
Le fichier modele_billets.joblib doit être dans le même dossier que ce script.
"""

import sys
from pathlib import Path

import joblib
import pandas as pd


def charger_artefacts():
    chemin = Path(__file__).resolve().parent / "modele_billets.joblib"
    if not chemin.exists():
        raise FileNotFoundError(
            f"modele_billets.joblib introuvable dans {chemin.parent}.\n"
            "Placez le fichier joblib à côté de ce script."
        )
    try:
        return joblib.load(chemin)
    except Exception as e:
        raise RuntimeError(
            "Impossible de charger le modèle. Version de scikit-learn probablement "
            f"incompatible ({e}).\nEssayez : pip install -U scikit-learn joblib"
        ) from e


def lire_fichier(chemin):
    chemin = Path(chemin)
    if chemin.suffix.lower() in (".xlsx", ".xls"):
        return pd.read_excel(chemin)
    return pd.read_csv(chemin, sep=None, engine="python")


def predire(df, artefacts):
    colonnes = artefacts["colonnes_features"]
    manquantes = [c for c in colonnes if c not in df.columns]
    if manquantes:
        raise ValueError(
            f"Colonnes absentes du fichier : {', '.join(manquantes)}.\n"
            f"Colonnes attendues : {', '.join(colonnes)}"
        )

    X = df[colonnes].apply(pd.to_numeric, errors="coerce")

    # Imputation de margin_low quand les autres mesures sont complètes
    predicteurs = artefacts["predicteurs_imputation"]
    imputables = X["margin_low"].isna() & X[predicteurs].notna().all(axis=1)
    if imputables.any():
        X.loc[imputables, "margin_low"] = artefacts["imputation_margin_low"].predict(
            X.loc[imputables, predicteurs]
        )

    resultat = df.copy()
    resultat["prediction"] = pd.NA
    resultat["proba_vrai"] = pd.NA

    valides = X.notna().all(axis=1)
    if valides.any():
        pred = artefacts["pipeline"].predict(X[valides])
        proba = artefacts["pipeline"].predict_proba(X[valides])[:, 1]
        resultat.loc[valides, "prediction"] = ["Vrai" if p else "Faux" for p in pred]
        resultat.loc[valides, "proba_vrai"] = proba.round(4)

    return resultat, int(imputables.sum()), int((~valides).sum())


def resumer(resultat, n_imputes, n_ignores):
    total = len(resultat)
    vrais = (resultat["prediction"] == "Vrai").sum()
    faux = (resultat["prediction"] == "Faux").sum()
    predits = vrais + faux
    lignes = [
        f"Billets analysés : {total}",
        f"Vrais : {vrais} ({vrais / predits:.1%})" if predits else "Vrais : 0",
        f"Faux : {faux} ({faux / predits:.1%})" if predits else "Faux : 0",
    ]
    if n_imputes:
        lignes.append(f"margin_low imputé sur {n_imputes} ligne(s)")
    if n_ignores:
        lignes.append(f"{n_ignores} ligne(s) non prédite(s) (mesures manquantes ou invalides)")
    return "\n".join(lignes)


def main():
    import tkinter as tk
    from tkinter import filedialog, messagebox

    racine = tk.Tk()
    racine.withdraw()

    chemin = filedialog.askopenfilename(
        title="Choisir le fichier de billets à analyser",
        filetypes=[("Fichiers CSV et Excel", "*.csv *.xlsx *.xls"),
                   ("Tous les fichiers", "*.*")],
    )
    if not chemin:
        print("Aucun fichier sélectionné.")
        return

    try:
        artefacts = charger_artefacts()
        df = lire_fichier(chemin)
        resultat, n_imputes, n_ignores = predire(df, artefacts)
    except Exception as e:
        messagebox.showerror("Erreur", str(e))
        print(f"Erreur : {e}", file=sys.stderr)
        return

    sortie = Path(chemin).with_name(Path(chemin).stem + "_predictions.csv")
    resultat.to_csv(sortie, sep=";", index=False)

    resume = resumer(resultat, n_imputes, n_ignores)
    print(resume)
    print("\nDétail :")
    print(resultat[["prediction", "proba_vrai"]].to_string())
    print(f"\nRésultats exportés : {sortie}")

    messagebox.showinfo("Prédictions terminées", f"{resume}\n\nExport : {sortie}")


if __name__ == "__main__":
    main()